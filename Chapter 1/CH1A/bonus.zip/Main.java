import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        
        Scanner scnr = new Scanner(System.in);
        
        System.out.print("Enter a value for N: ");
        
            int n = scnr.nextInt();
            char ch = 219;
            
            for (int i = 0; i < n; i++) {
                if (i == 0) {
                    for (int j = 0; j < n; j++)
                    System.out.print("+---");
                    System.out.println("+");
                    
                }
                
                for (int j = 0; j < n; j++){
                    if((i%2==0 && j%2==0) || (i%2==1 && j%2==1))
                    System.out.printf("|%c%c%c", ch, ch, ch);
                    
                    else
                    System.out.print("| ");
                    
                }
                
                System.out.println("|");
                
                for (int j = 0; j < n; j++)
                    System.out.print("+---");
                    System.out.println("+");
                
            }

    }
}