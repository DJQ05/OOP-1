import java.util.Scanner;

public class QuadFormula {

    public static void main(String[] args) {
    
        //ints
        Scanner sc = new Scanner(System.in);
        double a, b, c;
        double root1, root2, imag;
        
        //display intro message
        System.out.println("The Quadratic formula");
        
        //get coefficients from user
        System.out.println("a: ");
        a = sc.nextDouble();
        System.out.println("b: ");
        b = sc.nextDouble();
        System.out.println("c: ");
        c = sc.nextDouble();
        
        //calculate the disciminant
        double discrim;
        discrim = b * b - 4 * a * c;
        
        //modify output depending on sign of discrim
        if (discrim > 0) {
            root1 = (-b + Math.sqrt(discrim)) / (2 * a);
            root2 = (-b - Math.sqrt(discrim)) / (2 * a);
            System.out.println("Two real roots: " + root1 + " and " + root2);
        } 
        else if (discrim < 0) { //two imaginary roots
            imag = Math.sqrt(-discrim) / (2 * a);
            System.out.println("Two imaginary roots: " + (-b / 2 * a) + "+- i" + imag);
        }
        else {
            root1 = -b / (2 * a);
            System.out.println("One real root: " + root1);
        }
    }
    
}
