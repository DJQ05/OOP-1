import java.util.*;

public class Main {
     
    public static void main(String[] args) {
        
        Scanner obj=new Scanner(System.in);
        char gameStatus='y';
        
        // to start the game
        int gameCount=0;
        
        // to count total game played 
        int gameWon=0;
        int gameLose=0;
        
        while(gameStatus!='n') 	{
            int randomNumber = (int)(Math.random()*(101-0+1)+0);
            
            // to generate number between 0-100
            int count=5;
            int i=1;
            
            while(i<=count) {
                System.out.print(i+": Enter your guess: ");
                int x= obj.nextInt();
                
                // taking user input
                if(x==randomNumber) {
                    gameWon++;
                    System.out.println("You won the game!");
                    System.out.println();
                    break;
                    
                } else if(x>randomNumber) {
                    System.out.println("Your guess is too high!");
                    
                } else {
                    System.out.println("Your guess is too low!");
                    
                }
                    i++;
                
            }
                    // if i greater than count i.e. user loss 
                    if(i>count) {
                        System.out.println("The number is "+ randomNumber);
                        System.out.println("You lose the game!");
                            gameLose++;
                        System.out.println();
                        
                    }
                            gameCount++;
                            
                            System.out.println("Do you want to play again[y/n]: ");
                            gameStatus=obj.next().charAt(0);
            
        }
        
        //  displaying player stats
        System.out.println();
        System.out.println("Player statistics");
        System.out.println("_ _ _ _ _ _ _ _ _ _ ");
        System.out.println("Number of games: "+gameCount);
            float wonPercentage;
            float losePercentage;
            
            // calculate percetage
            wonPercentage = (gameWon*100)/gameCount;
            losePercentage = (gameLose*100)/gameCount;
            System.out.println("Game won: "+gameWon+" ["+wonPercentage+" %]");
            System.out.println("Game lose: "+gameLose+" ["+losePercentage+" %]"); 	
        
    } 
    
}


















