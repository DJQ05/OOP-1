import java.util.Scanner;//import Scanner class 
import static java.lang.System.out; //omit "system" keyword

public class Main{
    
    public static boolean check(String input){ //method checker if valid or invalid
        for(int x = 0; x < input.length(); x++){ //loop through each character to check if there's a letter
            if(Character.isAlphabetic(input.charAt(x))){ //if true
                return false; //return false (invalid)
            }
        }
        if(input.length() != 8){ //if input is less than or greater than 8
            return false; //return false
        }
    
        if(((Integer.parseInt(String.valueOf(input.charAt(0))) + Integer.parseInt(String.valueOf(input.charAt(1)))
        + Integer.parseInt(String.valueOf(input.charAt(4))) + Integer.parseInt(String.valueOf(input.charAt(6))))) % 10
        == Integer.parseInt(String.valueOf(input.charAt(7)))){ //if the 1st, 2nd, 5th, and 7th number is equal to the 8th
            return true; //return true
        }else{
            return false; //return false
        }
    }
    
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in); //Scanner object
        String input; //input
        int num; //number of inputs
        int v = 0, in = 0; //counters of valid and invalid input
        
        out.print(">> Enter the numbers of account numbers to be verified: ");
        num = sc.nextInt();//input num
        sc.nextLine();//clear input buffer
        
        for(int x = 0; x < num; x++){ //iterate through num
            out.print(">> Enter an 8-digit account number: ");
            input = sc.nextLine(); //enter input
            if(check(input)){ //if check is true -> valid
                out.println(" -- " + input + " is valid account number"); //print
                v++; //increment valid counter
                out.println(); //endline
            }else{ //invalid
                out.println(" -- " + input + " is invalid account number"); //print
                in++; //increment invalid counter
                out.println(); //endline
            }
        }
            
            out.println(" -- No. of Valid Account Number(s): " + v); //print the number of valid inputs
            out.println(" -- No. of Invalid Account Number(s): " + in); //print the number of invalid inputs
    }
}