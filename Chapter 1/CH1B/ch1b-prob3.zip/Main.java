import java.util.Scanner;                                         //import Scanner class
import static java.lang.System.out;                                 //omit "System" keyword

public class Main{
    
    public static boolean letterP(String input){                     //letter palingram checker
        input = input.replaceAll("[^a-zA-Z0-9]", " ").trim();       //replace all punctuations 
        String in = "";                                         //string input will hold the reversed value of the input
        input = input.toUpperCase();                            //convert input to uppercase
        for(int x = input.length()-1; x > -1; x--){             //access each character and begin at N where N is the length of the input
            in += input.charAt(x);                              //in += the accessed character
        }
        input = input.replaceAll("\\s", "").trim();             //remove all spaces
        in = in.replaceAll("\\s", "").trim();                   //remove all spaces
        if(in.equals(input)){                                   //if the reversed value is equals to the  original value
            return true;                                        //return true
        }else{
            return false;                                           //return false
        }
        
    }
    
    public static boolean wordP(String input){                      //word palingram checker
        input = input.replaceAll("[^a-zA-Z0-9]", " ").trim();           //remove all spaces
        int l = input.length();                                             //length of the string
        String input_copy = input.toUpperCase(), in = "";                   //copy of the original input and the reversed value
        int index = input.lastIndexOf(" ");                                 //get the lastIdexof space
        for(int i = 0; i < l; i++){                                         //loop through each words
            if(index < 0){                                                  //if index is less than 0 means theres only 1 word left
                index = 0;                                                  //index is equals 0
                in += " ";                                                  //add space
            }
            in += input.substring(index, input.length());                   //in += the last index of space up to the length 
            input = input.substring(0, index);                              //update the value of input 
            index = input.lastIndexOf(" ");                                 //update the value of index
            if(input.equals("")){                                           //if the input is empty
                break;                                                      //break
            }
        }
        in = in.trim();                                                     //trim the spaces at index 0 and index(n) where n is the length of the string
        if(in.toUpperCase().equals(input_copy)){                                //if the reversed value is equals to the original copy
            return true;                                                    //return true
        }else{
            return false;                                                   //return false
        }
    }
    
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);                                //Scanner obj
        String input;                                                       //input
        char loop;                                                          //loop
        
        do{
            
            out.print("Enter a phrase/sentence: ");
            input = sc.nextLine();                                          //user input
            if(letterP(input) && wordP(input)){                             //method call, if both letterP and WordP returns true
                out.println(" -- A PALINGRAM (Letter & Word Palingram)");       //print
            }else if(letterP(input)){                                           //if letterP returns true
                out.println(" -- A PALINGRAM (Letter Palingram)");              //print
            }else if(wordP(input) && input.contains(" ")){                              //if WordP return true and there are multiple words present
                out.println(" -- A PALINGRAM (Word Palingram)");                //print
            }else{
                out.println(" -- NOT A PALINGRAM");                             //print if both method returns false
            }
            
            out.print("Enter 'Y' to try again: ");
            loop = sc.next().charAt(0);                     //char input
            sc.nextLine();                          //clear buffer
        }while(loop == 'y' || loop == 'Y');         //continue loop if loop = 'y' or 'Y'
            out.println(" -- Program Terminated"); //print if loop breaks
        
        
    }
}