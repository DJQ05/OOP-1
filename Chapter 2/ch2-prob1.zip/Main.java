import java.util.*;
import java.util.Scanner;
import java.util.Arrays;
import java.lang.Math;

public class Main {
    
    public static void main( String[] args ) {
        char answer = 'n';

        do {
        // Array Initialization
        int arr[][] = new int [3][2];

        Scanner sc = new Scanner(System.in);

        do {
        // X-axis of the 1st Coordinate
        System.out.print("Enter the Coordinate for First X-axis: ");
        arr[0][0] = sc.nextInt();
        
        // Y-axis of the 1st Coordinate
        System.out.print("Enter the Coordinate for First Y-axis: ");
        arr[0][1] = sc.nextInt();

        } while (arr[0][0] == 0 && arr[0][1] == 0);
        
        do {
            // X-axis of the 2nd Coordinate
            System.out.print("Enter the Coordinate for Second X-axis: ");
            arr[1][0] = sc.nextInt();
        
            // Y-axis of the 2nd Coordinate
            System.out.print("Enter the Coordinate for Second Y-axis: ");
            arr[1][1] = sc.nextInt();

        } while ((arr[1][0] == 0 && arr[1][1] == 0) || (arr[0][0] == arr[1][0] && arr[0][1] == arr[1][1]));

        do {
            // X-axis of the 3rd Coordinate
            System.out.print("Enter the Coordinate for Third X-axis: ");
            arr[2][0] = sc.nextInt();
        
            // Y-axis of the 3rd Coordinate
            System.out.print("Enter the Coordinate for Third Y-axis: ");
            arr[2][1] = sc.nextInt();

        } while ((arr[2][0] == 0 && arr[2][1] == 0) || 
                 (arr[0][0] == arr[2][0] && arr[0][1] == arr[2][1]) || 
                 (arr[1][0] == arr[2][0] && arr[1][1] == arr[2][1]));

        // String Declaration
        String first_coor = "";
        String second_coor = "";
        String third_coor = "";

        // Finding the Quadrant it Belongs to
        // First Coordinate
        if(arr[0][0] > 0 && arr[0][1] > 0){
            first_coor = "Quadrant I";
        }
        else if(arr[0][0] < 0 && arr[0][1] > 0) {
            first_coor = "Quadrant II";
        }
        else if(arr[0][0] < 0 && arr[0][1] < 0) {
            first_coor = "Quadrant III";
        }
        else if(arr[0][0] > 0 && arr[0][1] < 0) {
            first_coor = "Quadrant IV";
        }
        else if(arr[0][0] == 0){
            first_coor = "X-Axis";
        }
        else if(arr[0][1] == 0){
            first_coor = "Y-Axis";
        }
        
        // Second Coordinate
        if(arr[1][0] > 0 && arr[1][1] > 0){
            second_coor = "Quadrant I";
        }
        else if(arr[1][0] < 0 && arr[1][1] > 0) {
            second_coor = "Quadrant II";
        }
        else if(arr[1][0] < 0 && arr[1][1] < 0) {
            second_coor = "Quadrant III";
        }
        else if(arr[1][0] > 0 && arr[1][1] < 0) {
            second_coor = "Quadrant IV";
        }
        else if(arr[1][0] == 0){
            second_coor = "X-Axis";
        }
        else if(arr[1][1] == 0){
            second_coor = "Y-Axis";
        }

        // Third Coordinate
        if(arr[2][0] > 0 && arr[2][1] > 0){
            third_coor = "Quadrant I";
        }
        else if(arr[2][0] < 0 && arr[2][1] > 0) {
            third_coor = "Quadrant II";
        }
        else if(arr[2][0] < 0 && arr[2][1] < 0) {
            third_coor = "Quadrant III";
        }
        else if(arr[2][0] > 0 && arr[2][1] < 0) {
            third_coor = "Quadrant IV";
        }
        else if(arr[2][0] == 0){
            third_coor = "X-Axis";
        }
        else if(arr[2][1] == 0){
            third_coor = "Y-Axis";
        }

        System.out.println("");

        // Absolute value of each point
        int point_1 = Math.abs(arr[0][0]) + Math.abs(arr[0][1]);
        int point_2 = Math.abs(arr[1][0]) + Math.abs(arr[1][1]);
        int point_3 = Math.abs(arr[2][0]) + Math.abs(arr[2][1]);

        // Find the Nearest to the Origin
        // If the first point is the nearest to the Origin
        if((Math.abs(arr[0][0]) <= Math.abs(arr[1][0]) && Math.abs(arr[0][0]) <= Math.abs(arr[2][0])) && 
            point_1 < point_2 && point_1 < point_3 || 
           (Math.abs(arr[0][1]) <= Math.abs(arr[1][1]) && Math.abs(arr[0][1]) <= Math.abs(arr[2][1])) && 
            point_1 < point_2 && point_1 < point_3){
                System.out.println("----- NEAREST -----");
                System.out.println("The Nearest to the Origin is the first point which has the x-coordinate of " 
                                    +  arr[0][0]+ " and y-coordinate of " + arr[0][1]);
                System.out.println("The point is in the " + first_coor);
        }
        // If the second point is the nearest to the Origin
        else if((Math.abs(arr[1][0]) <= Math.abs(arr[0][0]) && Math.abs(arr[1][0]) <= Math.abs(arr[2][0])) &&
                point_2 < point_1 && point_2 < point_3 || 
                (Math.abs(arr[1][1]) <= Math.abs(arr[1][0]) && Math.abs(arr[1][1]) <= Math.abs(arr[2][1]) &&
                point_2 < point_1 && point_2 < point_3)){
                    System.out.println("----- NEAREST -----");
                    System.out.println("The Nearest to the Origin is the second point which has the x-coordinate of " 
                                        +  arr[1][0]+ " and y-coordinate of " + arr[1][1]);
                    System.out.println("The point is in the " + second_coor);
        }
        // If the third point is the nearest to the Origin
        else if((Math.abs(arr[2][0]) <= Math.abs(arr[0][0]) && Math.abs(arr[2][0]) <= Math.abs(arr[1][0])) &&
                point_3 < point_1 && point_3 < point_2 || 
                (Math.abs(arr[2][1]) <= Math.abs(arr[0][1]) && Math.abs(arr[2][1]) <= Math.abs(arr[1][1])) &&
                point_3 < point_1 && point_3 < point_2){
                    System.out.println("----- NEAREST -----");
                    System.out.println("The Nearest to the Origin is the third point which has the x-coordinate of " 
                                        +  arr[2][0]+ " and y-coordinate of " + arr[2][1]);
                    System.out.println("The point is in the " + third_coor);
        }

        // Find the Farthest from the Origin
        // If the first point is the farthest to the Origin
        if((Math.abs(arr[0][0]) >= Math.abs(arr[1][0]) && Math.abs(arr[0][0]) >= Math.abs(arr[2][0])) &&
            point_1 > point_2 && point_1 > point_3 || 
           (Math.abs(arr[0][1]) >= Math.abs(arr[1][1]) && Math.abs(arr[0][1]) >= Math.abs(arr[2][1])) &&
            point_1 > point_2 && point_1 > point_3){
            System.out.println("----- FARTHEST -----");
            System.out.println("The Farthest to the Origin is the first point which has the x-coordinate of " 
                                +  arr[0][0]+ " and y-coordinate of " + arr[0][1]);
            System.out.println("The point is in the " + first_coor);
        }
        // If the second point is the farthest to the Origin
        else if((Math.abs(arr[1][0]) >= Math.abs(arr[0][0]) && Math.abs(arr[1][0]) >= Math.abs(arr[2][0])) &&
            point_2 > point_1 && point_2 > point_3|| 
            (Math.abs(arr[1][1]) >= Math.abs(arr[1][0]) && Math.abs(arr[1][1]) >= Math.abs(arr[2][1])) &&
            point_2 > point_1 && point_2 > point_3){
                System.out.println("----- FARTHEST -----");
                System.out.println("The Farthest to the Origin is the second point which has the x-coordinate of " 
                                    +  arr[1][0]+ " and y-coordinate of " + arr[1][1]);
                System.out.println("The point is in the " + second_coor);
        }
        // If the third point is the farthest to the Origin
        else if((Math.abs(arr[2][0]) >= Math.abs(arr[0][0]) && Math.abs(arr[2][0]) >= Math.abs(arr[1][0])) &&
            point_2 > point_1 && point_2 > point_3|| 
            (Math.abs(arr[2][1]) >= Math.abs(arr[0][1]) && Math.abs(arr[2][1]) >= Math.abs(arr[1][1])) &&
            point_3 > point_1 && point_3 > point_2){
                System.out.println("----- FARTHEST -----");
                System.out.println("The Farthest to the Origin is the third point which has the x-coordinate of " 
                                    +  arr[2][0]+ " and y-coordinate of " + arr[2][1]);
                System.out.println("The point is in the " + third_coor);
        }

        System.out.println();
        System.out.print("Want to Try Again[Y/N]?: ");
        answer = sc.next().charAt(0);

        } while (answer != 'N' || answer != 'n');
    }
}