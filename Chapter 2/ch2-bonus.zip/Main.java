import java.util.Scanner;

public class Main {
    
    public static void main( String[] args ) {
        // Ascii Code 219 = █

        // Variable Initialization
        int n_value = 0;
        char loop = 'Y';
        Scanner scanner = new Scanner(System.in);

        // Print Out
        System.out.println("N x N CHECKERED BOARD MAKER");
        System.out.println("---------------------------");
        System.out.println("");

        // While Loop to Check for Valid Input [1 - 20]
        while (loop == 'Y' || loop == 'y') {
            // Ask for the Value of N and store to n_value
            System.out.print("Enter a value for N: ");
            n_value = scanner.nextInt();
            System.out.println("");
            
            // Is the input value valid
            if (n_value >= 1 && n_value <= 20) { 

                // Print Out Board
                // Row
                for (int i = 1; i <= n_value; i++) { 
                    for (int j = 1; j <= n_value; j++) {
                        System.out.print("+---");

                    }
                    System.out.println("+"); 
                    // print the block if i is odd
                    if (i % 2 == 0) { 
                        for (int j = 1; j <= n_value; j++) { 
                            if (j % 2 == 0) {
                                System.out.print("|███");
                            } else if (j % 2 == 1) {
                                System.out.print("|   ");
                            }
                        }
                    }
                    // print the empty blocks if i is even
                    else if (i % 2 == 1) {
                        for (int j = 1; j <= n_value; j++) {
                            if (j % 2 == 1) {
                                System.out.print("|███");
                            } else if (j % 2 == 0) {
                                System.out.print("|   ");
                            }
                        }
                    }
                    System.out.println("|");
                }
                // Last Row
                for (int j = 1; j <= n_value; j++) { 
                    System.out.print("+---");
                }
                System.out.println("+");
                System.out.println("");
                
                
                // Ask the User if wants to try again
                System.out.print("\n" + "Do You Want To Try Again?[Y/N]: ");
                loop = scanner.next().charAt(0);
                System.out.println();
            } else {
                // Invalid Input Output
                System.out.println("Valid Input [1 - 20]");
                System.out.print("\n" + "Do You Want To Try Again?[Y/N]: ");
                loop = scanner.next().charAt(0);
                System.out.println();
            }
        }
    }
}

