import java.util.Scanner;;

public class Main {
    
    public static void main( String[] args ) {
        // Variable Initialization
        char answer = 'Y';

        // Initialize the scanner
        Scanner sc = new Scanner(System.in);

        do {
            // Variable Initialization
            int tile_length_cm = 0;
            int tile_width_cm = 0;
            int floor_length_meter = 0;
            int floor_width_meter = 0;

            // Ask for the input
            System.out.print( "Enter the Length of the Tile in centimeter: ");
            tile_length_cm = sc.nextInt();
            System.out.print( "Enter the Width of the Tile in centimeter: ");
            tile_width_cm = sc.nextInt();
            System.out.print( "Enter the Length of the Floor in meter: ");
            floor_length_meter = sc.nextInt();
            System.out.print( "Enter the Width of the Floor in meter: ");
            floor_width_meter = sc.nextInt();

            // Convertion
            int tile_centimeter_squared = tile_length_cm * tile_width_cm;
            int tile_to_meter = tile_centimeter_squared / 100;
            int floor_meter_squared = floor_length_meter * floor_width_meter * 100;

            // Dividing to get the Approximate Number of Tiles
            int tiles_number = floor_meter_squared / tile_to_meter;

            // Output
            System.out.println("Approximate Number of Tiles: " + tiles_number);
            System.out.println();

            // Ask the user if want to try again
            System.out.print("Do You Want To Try Again?[Y/N]: ");
            answer = sc.next().charAt(0);
            System.out.println();

        } while (answer == 'Y' || answer == 'y');
    }
}
